
import java.util.Scanner;

import java.util.Random;

public class PROYECTOJUEGO {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner (System.in);
		Random random = new Random();
		
		int vidas = 3;
		int pistasEncontradas = 0; // contador de pistas reunidas
		
		boolean continuar = true; // para controlar el flujo
		
		
		// aquí esta la narrativa del juego y las reglas
		System.out.println("Bienvenido al refujio de los desaparecidos");
		System.out.println("-------------------------------------------");
		System.out.println("Te encuentras en un pequeño pueblo en ruinas, donde el eco del pasado resuena demasiado");
		System.out.println("Personas han desaparecido aquí misteriosamente y tu estas dispuesto/a a encontrarlos");
		System.out.println("Para descubrir el paradero de las personas desaparecidas, debes acertar unas adivinanzas y adivinar un número aleatorio");
		System.out.println("Una vez hayas acertado, podrás acceder a un mapa que se encuentra en el bosque con información y ubicación sobre donde estan los desaparecidos");
		System.out.println("-------------------------------------------");
		
		// menú donde el usuario puede elegir las opciones de los escenarios
		
		while (continuar) {
			System.out.println("----menú----");
			System.out.println("1.Plaza central");
			System.out.println("2.Bosque oscuro");
			System.out.println("3.Casa abandonada");
			System.out.println("4.Antigua biblioteca");
			System.out.println("5.Antiguo cementerio");
			System.out.println("6.Salir del juego");
			System.out.println("Elige un escenario para explorar");
			
			int opcion = scanner.nextInt();
			
			switch (opcion) {
			
			case 1:
                System.out.println("Estás en la Plaza Central. La atmósfera es sombría, con edificios en ruinas a tu alrededor.");
                System.out.println("Encuentras un viejo cartel con una pista escrita en él.");
                System.out.println("1. Leer la pista");
                System.out.println("2. Ignorar la pista y seguir explorando");
                int decision = scanner.nextInt();
                
                if (decision == 1) {
                    System.out.println("La pista dice: 'Busca en la biblioteca las palabras de los que ya no están'.");
                } else {
                    System.out.println("Decides ignorar la pista y mirar a tu alrededor.");
                }
                System.out.println("Presiona Enter para continuar...");
                scanner.nextLine();
                scanner.nextLine();
                
                break;
                
                
			case 2:
                System.out.println("Te adentras en el Bosque Oscuro. Los árboles son densos y el silencio es abrumador.");
                System.out.println("Sabes que debes adivinar el número y responder las adivinanzas para poder obtener el mapa con la información de los desaparecidos. Esta información se encuentra aquí");
                System.out.println("Las adivinanzas se encuentran en la biblioteca, y el número a adivinar en el cementerio");
                System.out.println("Presiona Enter para continuar...");
                
                scanner.nextLine();
                scanner.nextLine();
                
                break;
                
		
			case 3:
			    System.out.println("Has llegado a una Casa Abandonada donde vivía una niña. Las ventanas están rotas y el jardín lleno de juguetes rotos.");
			    System.out.println("Te encuentras con la niña que te desafía a jugar un juego de tres en raya.");

			    // El tablero vacío
			    char[][] tablero = {
			        {' ', ' ', ' '},
			        {' ', ' ', ' '},
			        {' ', ' ', ' '}
			    };

			    // Variable para controlar el turno
			    char simbolo = 'X';
			    boolean ganador = false;

			    // Juego de tres en raya
			    for (int turno = 0; turno < 9 && !ganador; turno++) {
			        System.out.println("Turno " + (turno + 1) + ": ");
			        System.out.println("Elige una fila (0-2): ");
			        int fila = scanner.nextInt();
			        System.out.println("Elige una columna (0-2): ");
			        int columna = scanner.nextInt();

			        // Validar la posición
			        if (fila >= 0 && fila < 3 && columna >= 0 && columna < 3 && tablero[fila][columna] == ' ') {
			            tablero[fila][columna] = simbolo;

			            // Comprobar si hay un ganador
			            // Comprobar filas
			            for (int i = 0; i < 3; i++) {
			                if (tablero[i][0] == simbolo && tablero[i][1] == simbolo && tablero[i][2] == simbolo) {
			                    ganador = true; // Ganador en fila
			                }
			            }

			            // Comprobar columnas
			            for (int i = 0; i < 3; i++) {
			                if (tablero[0][i] == simbolo && tablero[1][i] == simbolo && tablero[2][i] == simbolo) {
			                    ganador = true; // Ganador en columna
			                }
			            }

			            // Comprobar diagonales
			            if ((tablero[0][0] == simbolo && tablero[1][1] == simbolo && tablero[2][2] == simbolo) ||
			                (tablero[0][2] == simbolo && tablero[1][1] == simbolo && tablero[2][0] == simbolo)) {
			                ganador = true; // Ganador en diagonal
			            }

			            // cambiar el símbolo para el siguiente turno
			            simbolo = (simbolo == 'X') ? 'O' : 'X';

			            // Imprimir el tablero actual
			            System.out.println("Tablero actual:");
			            for (char[] filaTablero : tablero) {
			                for (char celda : filaTablero) {
			                    System.out.print(celda + " | ");
			                }
			                System.out.println();
			            }
			        } else {
			            System.out.println("Posición ocupada o inválida, intenta otra.");
			            turno--; // repetir turno si posicion es ocupada o invalida
			        }
			    }

			    // Mensaje final según el resultado
			    if (ganador) {
			        System.out.println("¡Felicidades! El jugador " + (simbolo == 'X' ? 'O' : 'X') + " ha ganado.");
			    } else {
			        System.out.println("El juego ha terminado en empate.");
			    }

			    System.out.println("La niña se ríe y dice: 'Buen intento. Quizás la próxima vez ganes'.");
			    System.out.println("Presiona Enter para continuar...");
			    scanner.nextLine(); // Esto se necesita para consumir el salto de línea
			    scanner.nextLine();
			    break; // Para salir del case 3


                    
                case 4:
                    System.out.println("Te encuentras en una Antigua Biblioteca. Los libros cubiertos de polvo parecen contener secretos olvidados");
                    System.out.println("Al explorar, un anciano aparece y te dice que te hará una pregunta.");
                    
                    System.out.println("Pregunta: ¿Cómo se llama el proceso de convertir código fuente en un programa ejecutable?");
                    System.out.print("Escribe tu respuesta: ");
                    String respuesta = scanner.next();
                    
                    if (respuesta.equalsIgnoreCase("compilación")) {
                        System.out.println("¡Correcto! El anciano te dice: 'Has encontrado una pista sobre el paradero de los desaparecidos.");
                        
                        pistasEncontradas++;
                        System.out.println("Has encontrado " + pistasEncontradas + " pistas.");
                        
                        System.out.println("Ahora te hará una segunda pregunta: 'En Java soy un tipo de dato, con true o false siempre estoy atado. ¿Quién soy?' ");
                        String respuesta2 = scanner.next();
                        
                        if (respuesta2.equalsIgnoreCase("boolean")) {
                            System.out.println("¡Correcto! Has encontrado una pista más.");
                            pistasEncontradas++;
                            System.out.println("Una última adivinanza: 'En Java soy la estructura que repite sin parar, hasta que la condición deje de mandar. ¿Quién soy?' ");
                            String respuesta3 = scanner.next();
                            
                            if (respuesta3.equalsIgnoreCase("bucle")) {
                                System.out.println("¡Correcto! Has encontrado una pista más.");
                                pistasEncontradas++;
                                
                                System.out.println("Llevas " + pistasEncontradas + " pistas encontradas.");
                                System.out.println("El anciano desaparece sin decirte nada, entonces, una hoja de papel cae de una estantería.");
                                System.out.println("Te acercas con cuidado, temiendo encontrar algo malo.");
                                System.out.println("Nada más levantar el papel, te das cuenta de que es un mapa, con un lugar específico rodeado en él.");
                                System.out.println("Otra hoja aparece en la estantería: 'Coge el único libro que hay en la estantería'");
                                System.out.println("Sin dudarlo, lo sacas y una puerta secreta se abre.");
                                System.out.println("Los desaparecidos están allí..");
                                System.out.println("Te das cuenta de que el mapa y las pistas te han llevado al lugar correcto.");
                                System.out.println("Has completado el juego con éxito. ¡Felicidades, héroe del pueblo!");
                                System.out.println("Has terminado el juego con " + vidas + " vidas y con " + pistasEncontradas + " pistas encontradas.");
                                break;
                                
                            } else {
                                System.out.println("Respuesta incorrecta. El anciano desaparece.");
                                System.out.println("Has perdido una vida.");
                                vidas--;
                            }
                        } else {
                            System.out.println("Respuesta incorrecta. El anciano desaparece.");
                            System.out.println("Has perdido una vida.");
                            vidas--;
                        }
                    } else {
                        System.out.println("Respuesta incorrecta. El anciano desaparece.");
                    }
                    System.out.println("Presiona Enter para continuar...");
                    scanner.nextLine();
                    scanner.nextLine();
                    break;
                    
                case 5:
                    System.out.println("Te encuentras en el cementerio. Tienes que adivinar un número del 1 al 10 para poder leer el papel que se encuentra en el bosque");
                    int numeroSecreto = random.nextInt(10) + 1;
                    vidas = 3;
                    
                    while (vidas > 0) {
                        System.out.print("Adivina el número (1-10): ");
                        int numeroUsuario = scanner.nextInt();

                        if (numeroUsuario == numeroSecreto) {
                            System.out.println("Correcto! Ahora puedes leer el papel en el bosque.");
                            break;
                        } else {
                            vidas--;
                            System.out.println("Incorrecto. Te quedan " + vidas + " vidas.");
                        }
                    }

                    if (vidas == 0) {
                        System.out.println("No adivinaste el número. Intenta de nuevo.");
                    }
                    System.out.println("Presiona Enter para continuar...");
                    scanner.nextLine();
                    scanner.nextLine();
                    break;
                    
                case 6:
                    System.out.println("Saliendo del juego...");
                    continuar = false;
                    break;

                default:
                    System.out.println("Opción no válida. Intenta de nuevo.");
            }
        }

		scanner.close();
    }
		
}

